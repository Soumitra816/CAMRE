### Insight in Sight: Complaint Detection and Aspect-based Reasoning through Visually-grounded Reviews with VLLMs
The repository details the steps to run the scripts associated with the experiments mentioned in the paper
